"""WorthApply application entry points."""
