"""Streamlit UI for WorthApply."""
