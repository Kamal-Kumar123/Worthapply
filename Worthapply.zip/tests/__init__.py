"""WorthApply test suite."""
