"""WorthApply evaluation framework."""
